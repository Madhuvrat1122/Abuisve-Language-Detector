#importing required things
import pickle
import numpy as np
import pandas as pd
import string
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
#get the dataset
dataset = pd.read_csv('dataset/train.csv')[['comment_text','toxic']]
####data proprocessing
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
###data preprocessing
def text_process(mess):
    review = re.sub('[^a-zA-Z]', ' ', mess)
    review = review.lower()
    review = review.split()
    review = [word for word in review if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review]
    review = ' '.join(review)
    return [word for word in review.split()]
#vectorization
from sklearn.feature_extraction.text import CountVectorizer
bow_transformer = CountVectorizer(analyzer=text_process).fit(dataset['comment_text'])
pickle_out1 = open("bag_of_words.pickle","wb")
pickle.dump(bow_transformer, pickle_out1)
pickle_out1.close()
messages_bow = bow_transformer.transform(dataset['comment_text'])
#tfidf
from sklearn.feature_extraction.text import TfidfTransformer
tfidf_transformer = TfidfTransformer().fit(messages_bow)
pickle_out2 = open("new_tfidf.pickle","wb")
pickle.dump(tfidf_transformer, pickle_out2)
pickle_out2.close()

messages_tfidf = tfidf_transformer.transform(messages_bow)
#model
from sklearn.linear_model import LogisticRegression
classifier1 = LogisticRegression()
classifier1.fit(messages_tfidf, dataset['toxic'])
pickle_out3 = open("model.pickle","wb")
pickle.dump(classifier1, pickle_out3)
pickle_out3.close()

#********************************************THE END************************************
#==========================================================================================
