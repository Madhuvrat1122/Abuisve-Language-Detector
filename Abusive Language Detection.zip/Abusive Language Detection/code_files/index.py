import pickle
import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
#opening pickle file
#preprocessing of user input
#defining a function
def user_check1(user):
    spec_alph=['@','#','$','%','*']
    alph=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    df=pd.read_csv("dataset/bad-words.csv",header=None)
    for item in user.split():
        count=0
        for i in spec_alph:
            if i in item:
                for ch in item:
                    if ch==i:
                        count+=1
                for j in alph:
                    new_word=item.replace(i*count,j)
                    for j in df[0]:
                        if j==new_word:
                            user=user.replace(item,new_word)
                            break
    return user
#Another Method
def user_check2(user):
    df=pd.read_csv('dataset/bad-words.csv',header=None)
    for i in user.split():
        for item in df[0]:
            if i==item:
                j=i.rstrip('er')
                user=user.replace(i,j)
    return user
#text_process function
def text_process(mess):
    review = re.sub('[^a-zA-Z]', ' ', mess)
    review = review.lower()
    review = review.split()
    review = [word for word in review if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review]
    review = ' '.join(review)
    return [word for word in review.split()]
#taking user input
user=input("ENTER ANY TEXT TO CHECK WHEATHER IT IS ABUSIVE OR NOT =====>  ")
user_input=user_check1(user)
with open('pickles\\model.pickle','rb') as f2:
    ab2 = pickle.load(f2)
with open('pickles\\new_tfidf.pickle','rb') as f2:
    ab4 = pickle.load(f2)
with open('C:\\Users\\mv gupta\\Desktop\\project\\pickles\\bag_of_words.pickle','rb') as f2:
    ab3 = pickle.load(f2)
user1=ab3.transform([user_input])
user1=ab4.transform(user1)
result=ab2.predict(user1)
if result==1:
    print("***Abusive Text***")
else:
    user1=user_check2(user_input)
    user1=ab3.transform([user1])
    user1=ab4.transform(user1)
    result=ab2.predict(user1)
    if result==1:
        print("***Abusive Text***")
    else:
        print("***NOT Abusive Text***")