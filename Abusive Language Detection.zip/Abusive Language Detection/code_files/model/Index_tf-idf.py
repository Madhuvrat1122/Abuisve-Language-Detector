#importing required things
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import string
from nltk.stem import WordNetLemmatizer
%matplotlib inline  
#get the dataset
dataset = pd.read_csv('train.csv')[['comment_text','toxic']]
####data proprocessing
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
###data preprocessing
def text_process(mess):
    review = re.sub('[^a-zA-Z]', ' ', mess)
    review = review.lower()
    review = review.split()
    review = [word for word in review if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review]
    review = ' '.join(review)
    return [word for word in review.split()]
#vectorization
from sklearn.feature_extraction.text import CountVectorizer
bow_transformer = CountVectorizer(analyzer=text_process).fit(dataset['comment_text'])
# Print total number of vocab words
print(len(bow_transformer.vocabulary_))
#ow we can use .transform on our Bag-of-Words (bow) transformed object and transform the entire DataFrame of messages.
messages_bow = bow_transformer.transform(dataset['comment_text'])
##TF-IDF
#transforming the entire bag-of-words corpus into TF-IDF corpus at once:
from sklearn.feature_extraction.text import TfidfTransformer
tfidf_transformer = TfidfTransformer().fit(messages_bow)
messages_tfidf = tfidf_transformer.transform(messages_bow)
#logistic regression after train test split
# Accuracy:-95.83268
"===================================================================================
# fitting model for whole dataset
from sklearn.linear_model import LogisticRegression
classifier1 = LogisticRegression()
classifier1.fit(messages_tfidf, dataset['toxic'])
#preprocessing of user input
#defining a function
def user_check1(user):
    spec_alph=['@','#','$','%','*']
    alph=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    df=pd.read_csv("bad-words.csv",header=None)
    for item in user.split():
        count=0
        for i in spec_alph:
            if i in item:
                for ch in item:
                    if ch==i:
                        count+=1
                for j in alph:
                    new_word=item.replace(i*count,j)
                    for j in df[0]:
                        if j==new_word:
                            user=user.replace(item,new_word)
                            break
    return user
#Another Method
def user_check2(user):
    df=pd.read_csv("bad-words.csv",header=None)
    for i in user.split():
        string=''
        for j in i:
            string+=j
            for item in df[0]:
                if item==string:
                    user=user.replace(string,string+' ')
                    break
    return user
#taking user input
user=input("ENTER ANY TEXT TO CHECK WHEATHER IT IS ABUSIVE OR NOT =====>  ")
user=user_check1(user)
user=user_check2(user)
user=[user]
messages= bow_transformer.transform(user)
result=classifier1.predict(messages)
if result==1:
    print("***Abusive Text***")
else:
    print("***Not Abusive Text***")
#********************************************THE END************************************
#==========================================================================================



















