###data preprocessing
def text_process(mess):
    review = re.sub('[^a-zA-Z]', ' ', mess)
    review = review.lower()
    review = review.split()
    review = [word for word in review if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review]
    review = ' '.join(review)
    return [word for word in review.split()]
#vectorization
from sklearn.feature_extraction.text import CountVectorizer
bow_transformer = CountVectorizer(analyzer=text_process).fit(dataset['comment_text'])
# Print total number of vocab words
print(len(bow_transformer.vocabulary_))
#ow we can use .transform on our Bag-of-Words (bow) transformed object and transform the entire DataFrame of messages.
messages_bow = bow_transformer.transform(dataset['comment_text'])
##TF-IDF
#transforming the entire bag-of-words corpus into TF-IDF corpus at once:
from sklearn.feature_extraction.text import TfidfTransformer
tfidf_transformer = TfidfTransformer().fit(messages_bow)
messages_tfidf = tfidf_transformer.transform(messages_bow)
