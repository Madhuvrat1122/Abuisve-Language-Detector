#importing required things
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import string
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
#get the dataset
dataset = pd.read_csv('dataset/train.csv')[['comment_text','toxic']]
####data proprocessing
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
###data preprocessing
def text_process(mess):
    review = re.sub('[^a-zA-Z]', ' ', mess)
    review = review.lower()
    review = review.split()
    review = [word for word in review if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    review = [ps.stem(word) for word in review]
    review = ' '.join(review)
    return [word for word in review.split()]
#creating a pipeline
pipeline = Pipeline([
    ('bow', CountVectorizer(analyzer=text_process)),  # strings to token integer counts
    ('tfidf', TfidfTransformer()),  # integer counts to weighted TF-IDF scores
    ('classifier',LogisticRegression()),  # train on TF-IDF vectors w/ Naive Bayes classifier
])
pipeline.fit(dataset['comment_text'],dataset['toxic'])
pickling_on = open("abuse_detector.pickle","wb")
pickle.dump(pipeline, pickling_on)
pickling_on.close()

#********************************************THE END************************************
#==========================================================================================
