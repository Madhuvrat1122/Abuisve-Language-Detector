from flask import Flask, request, render_template, url_for
from spamvalid import spam_check
from abusevalid import abuse_check
from abusevalid import text_process
app = Flask(__name__)
@app.route("/index")
def home0():
    return render_template("index.html")

@app.route("/abuse")
def home1():
    return render_template("abuse.html")

@app.route("/spam")
def home2():
    return render_template("spam.html")

@app.route("/result1",methods=["POST"])
def output():
    form_data = request.form
    status = spam_check(form_data["message"])
    return render_template("layout.html",status=status)

@app.route("/result2",methods=["POST"])
def output1():
    form_data = request.form
    status1 = abuse_check(form_data["text"])
    return render_template("abuse.html",status1=status1)

if __name__ == "__main__":
    app.run(debug=True)
