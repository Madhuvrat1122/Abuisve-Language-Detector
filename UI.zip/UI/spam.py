import nltk
import pandas as pd
import string
from nltk.corpus import stopwords
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
messages=pd.read_csv('dataset/SMSSpamCollection',sep='\t',names=['label','messgae'])
def text_process(mess):
    nopunc=[char for char in mess if char not in string.punctuation]
    nopunc=''.join(nopunc)
    return [word for word in nopunc.split() if word.lower() not in stopwords.words('english')]
from sklearn.model_selection import train_test_split
msg_train, msg_test, label_train, label_test = train_test_split(messages['messgae'], messages['label'], test_size=0.2)
from sklearn.pipeline import Pipeline
pipeline1 = Pipeline([
    ('bow', CountVectorizer(analyzer=text_process)),  # strings to token integer counts
    ('tfidf', TfidfTransformer()),  # integer counts to weighted TF-IDF scores
    ('classifier', MultinomialNB()),  # train on TF-IDF vectors w/ Naive Bayes classifier
])
pipeline1.fit(msg_train,label_train)
pickling_on = open("spam_detector.pickle","wb")
pickle.dump(pipeline1, pickling_on)
pickling_on.close()