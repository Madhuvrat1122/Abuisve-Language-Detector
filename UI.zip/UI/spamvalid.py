import pickle
import numpy as np
import spam
def spam_check(user):
	with open('spam_detector.pickle','rb') as f2:
	    ab = pickle.load(f2)
	#user input
	user=np.array(user).reshape(-1,1)
	result=ab.predict(user)
	return result[0]